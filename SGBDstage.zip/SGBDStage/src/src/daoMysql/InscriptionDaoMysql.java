package src.daoMysql;

import src.beans.*;

import src.dao.*;
import java.util.ArrayList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.DriverManager;
import static javax.swing.UIManager.getString;
import static src.daoMysql.StageDaoMysql.*;


public class InscriptionDaoMysql implements InscriptionDao {
    
    private DaoFactory daoFactory;
    
    private static final String SQL_SELECT_TOUS="Select i.idInscr,i.dateInscription,i.datePaiement,i.idPart ,i.idStage from inscription as i ORDER BY i.idInscr ASC";

private static final String SQL_SELECT_PAR_PART="Select I.idPart,nomPart,prenomPart,adressePart,sexePart,naissPart ,I.idStage ,dateDeb,dateFin,ageMin,ageMax,prix,dateInscription,datePaiement from "+
"I inscription and P participant and S stage where I.idPart=P.idPart and I.idStage = S.idStage and I.idPart = ? order by 1";


private static final String SQL_SELECT_PAR_STAGE="Select I.idPart,nomPart,prenomPart,adressePart,sexePart,naissPart ,I.idStage ,dateDeb,dateFin,ageMin,ageMax,prix,dateInscription,datePaiement from "+
"I inscription and P participant and S stage where I.idPart=P.idPart and I.idStage = S.idStage and I.idStage=? order by 1";

private static final String SQL_INSERT="INSERT INTO inscription( idInscr, dateInscription, datePaiement, idPart, idStage) VALUES ( ? , ? , ? , ? , ? ) ";

private static final String SQL_DELETE="DELETE from inscription where idInscr = ? ";

private static final String SQL_UPDATE="UPDATE inscription SET  idInscr= ?,idPart=? ,idStage=? ,dateInscription=?, datePaiement=? WHERE idInscr= ?";

private        Connection con=null;
private        PreparedStatement prepStat=null;
private        ResultSet resu=null;
    
    public InscriptionDaoMysql(DaoFactory daoFactory)
    {
        this.daoFactory = daoFactory;
    }
     public InscriptionDaoMysql()
    {
        this.daoFactory = daoFactory;
    }
    
    /* renvoie une liste chaînée de toutes les inscriptions existantes */
    
    public ArrayList <Inscription> selectInscriptions() throws DaoException
    {
        ArrayList <Inscription> myList = new ArrayList();
                     
        try {
            con = daoFactory.getConnection();
            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, (Object[])null);
            resu = prepStat.executeQuery();
            while (resu.next())
            {  
                //creation des objets Inscription
                Inscription i=new Inscription();
                i.setIdInscr(resu.getInt(1));
                i.setDateInscription(resu.getDate(2));
                i.setDatePaiement(resu.getDate(3));
                i.setIdentPart(resu.getInt(4));
                i.setIdStage(resu.getInt(5));
                myList.add(i);
             }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
            
        return myList;
    }
     /*   public ArrayList <Inscription> selectInscriptionsParStage (int idStage) throws DaoException
    {
        
        ArrayList myList = new ArrayList();
        
        try {
            con = daoFactory.getConnection();
            if (idStage == -1)
                prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, (Object[])null);
            else
                prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_PAR_PART, false, idStage);
            
            resu = prepStat.executeQuery();
            while (resu.next())
            {                
                //création de l'objet Appareil
                myList.add(new Inscription(new Participant(resu.getInt(1),resu.getString(2),resu.getString(3),resu.getString(4),resu.getString(5),resu.getDate(6)),
                        new Stage(resu.getInt(7),resu.getDate(8),resu.getDate(9),resu.getInt(10),resu.getInt(11),resu.getInt(12),new Type(resu.getInt(13),resu.getString(14),resu.getString(15)),
                                new Moniteur(resu.getInt(16),resu.getString(17),resu.getString(18),resu.getString(19),resu.getString(20),resu.getString(21))),
                        resu.getDate(22),resu.getDate(23)));
             }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
        
        return myList;
    } 
    public ArrayList <Inscription> selectInscriptionsParPart (int idPart) throws DaoException
    {
        
        ArrayList myList = new ArrayList();
        
        try {
            con = daoFactory.getConnection();
            if (idPart == -1)
                prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, (Object[])null);
            else
                prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_PAR_PART, false, idPart);
            
            resu = prepStat.executeQuery();
            while (resu.next())
            {                
                //création de l'objet Appareil
                myList.add(new Inscription(,new Participant(resu.getInt(1),resu.getString(2),resu.getString(3),resu.getString(4),resu.getString(5),resu.getDate(6)),
                        new Stage(resu.getInt(7),resu.getDate(8),resu.getDate(9),resu.getInt(10),resu.getInt(11),resu.getInt(12),new Type(resu.getInt(13),resu.getString(14),resu.getString(15)),
                                new Moniteur(resu.getInt(16),resu.getString(17),resu.getString(18),resu.getString(19),resu.getString(20),resu.getString(21))),
                        resu.getDate(22),resu.getDate(23)));
             }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
        
        return myList;
    } 
    */

    @Override
    public void insertInscription(Inscription insc){
        
        try {
            /* Récupération d'une connexion depuis la Factory */
            con = daoFactory.getConnection();
          
            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_INSERT, true,
                     insc.getIdInscr(),
                     insc.getDateInscription(),
                     insc.getDatePaiement(),
                     insc.getIdentPart(),
                     insc.getIdStage()
                    );
            
            prepStat.execute();
            
        } 
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        /*catch (SQLException e) {
            throw new DaoException(e);
            
        }*/
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
        
    }
  
    public void deleteInscription (Integer idInscr) throws DaoException
    {
        try{
            con=daoFactory.getConnection();
            prepStat=DaoUtil.initialisationRequetePreparee(con, SQL_DELETE, false, idInscr);
            prepStat.execute();
        }
        catch(SQLException e)
        {
            throw new DaoException(e);
        }
        finally{
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
    }
    



    @Override
    public void updateInscription(Inscription insc,Integer oldId) throws DaoException {
        try{
            con=daoFactory.getConnection();
            prepStat=DaoUtil.initialisationRequetePreparee(con, SQL_UPDATE, true, 
                    insc.getIdInscr(),
                    insc.getIdentPart(),
                    insc.getIdStage(),
                    insc.getDateInscription(),
                    insc.getDatePaiement(),
                    oldId
                    );
            prepStat.executeUpdate();
        }
        catch(SQLException e)
        {
            throw new DaoException(e);
        }
        finally{
            DaoUtil.fermeturesSilencieuses(prepStat, con);
            
        }
    }

   
       

}
