/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src.daoMysql;

import src.beans.*;

import src.dao.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author RuthA
 */
public class MoniteurDaoMysql implements MoniteurDao{
    private DaoFactory daoFactory;
    
    private static final String SQL_SELECT_TOUS="Select idMoni , nomMoni, prenomMoni ,adresseMoni ,sexeMoni ,naissMoni from moniteur";

private static final String SQL_SELECT_PAR_STAGE="Select M.idMoni,M.nomMoni,M.prenomMoni,M.adresseMoni,M.sexeMoni,M.naissMoni from "+
"I inscription and P participant and S stage and T Type and M Moniteur where S.idType=T.idType and S.Moniteur=M.Moniteur and idStage=? order by 1";

private static final String SQL_SELECT_PAR_PART="Select M.idMoni,M.nomMoni,M.prenomMoni,M.adresseMoni,M.sexeMoni,M.naissMoni from "+
"I inscription and P participant and S stage and T Type and M Moniteur where S.idType=T.idType and S.Moniteur=M.Moniteur and idPart=? order by 1";


private static final String SQL_INSERT="INSERT INTO moniteur VALUES (?,?,?,?,?,?)";

private static final String SQL_DELETE="DELETE * from moniteur where idMoniteur=?";

private static final String SQL_UPDATE="UPDATE moniteur SET nomMoni= ?,prenomMoni=?,adresseMoni=?,sexeMoni=?,naissMoni=? WHERE M.idMoni=?";

private        Connection con=null;
private        PreparedStatement prepStat=null;
private        ResultSet resu=null;
    public MoniteurDaoMysql(DaoFactory daoFactory)
    {
        this.daoFactory = daoFactory;
    }
     public MoniteurDaoMysql()
    {
        this.daoFactory = daoFactory;
    }
    
    /* renvoie une liste chaînée de toutes les inscriptions existantes */
    
    public ArrayList <Moniteur> selectMoniteurs() throws DaoException
    {
        
        
        ArrayList <Moniteur> myList = new ArrayList();
                     
        try {
            con = daoFactory.getConnection();
            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, (Object[])null);
            resu = prepStat.executeQuery();
            while (resu.next())
            {  
                //creation des objets Moniteur
                myList.add(new Moniteur(resu.getInt(1),resu.getString(2),resu.getString(3),resu.getString(4),resu.getString(5),resu.getString(6)));
             }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
            
        return myList;
    }
  

    @Override
    public ArrayList<Moniteur> selectMoniteurParPart(Integer partId) throws DaoException {
        ArrayList <Moniteur> myList = new ArrayList();
                     
        try {
            con = daoFactory.getConnection();
            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, partId);
            resu = prepStat.executeQuery();
            while (resu.next())
            {  
                //creation des objets Moniteur
                myList.add(new Moniteur(resu.getInt(1),resu.getString(2),resu.getString(3),resu.getString(4),resu.getString(5),resu.getString(6)));
             }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
            
        return myList; 
    }

    @Override
    public ArrayList<Moniteur> selectMoniteurParStage(Integer moniteurId) throws DaoException {
      ArrayList <Moniteur> myList = new ArrayList();
                     
        try {
            con = daoFactory.getConnection();
            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, moniteurId);
            resu = prepStat.executeQuery();
            while (resu.next())
            {  
                //creation des objets Moniteur
                myList.add(new Moniteur(resu.getInt(1),resu.getString(2),resu.getString(3),resu.getString(4),resu.getString(5),resu.getString(6)));
             }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
            
        return myList;   
    }

    @Override
    public void insertMoniteur(Moniteur moni) throws DaoException {
        try{
            con=daoFactory.getConnection();
            prepStat=DaoUtil.initialisationRequetePreparee(con, SQL_INSERT, false,
                    moni.getIdMoni(),moni.getNomMoni(),moni.getPrenomMoni(),moni.getAdresseMoni(),moni.getSexeMoni(),moni.getNaissMoni());
            resu=prepStat.executeQuery();
        }
        catch(SQLException e){
            throw new DaoException(e);
        }finally{
        DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
    }

    public void deleteMoniteur(Integer idMoniteur) throws DaoException {
        try {
            /* Récupération d'une connexion depuis la Factory */
            con = daoFactory.getConnection();

            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_DELETE, false, idMoniteur);
            prepStat.executeUpdate();
        } 
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
    }

    @Override
    public void updateMoniteur(Moniteur moni) throws DaoException {
          try {
        /* Récupération d'une connexion depuis la Factory */
        con = daoFactory.getConnection();

            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_UPDATE, false,
                    moni.getIdMoni(),moni.getNomMoni(),moni.getPrenomMoni(),moni.getAdresseMoni(),moni.getSexeMoni(),moni.getNaissMoni());
            prepStat.executeUpdate();
        } 
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
    }
    
    
}
