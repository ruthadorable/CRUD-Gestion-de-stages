/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src.daoMysql;

import src.beans.*;
import src.dao.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author RuthA
 */
public class TypeDaoMysql implements TypeDao{

    private DaoFactory daoFactory;
    
    private static final String SQL_SELECT_TOUS="Select idType , denomType, descrType from type";

private static final String SQL_SELECT_PAR_PART="Select T.idType ,T.denomType, T.descrType,S.dateDeb,S.dateFin,S.ageMin,S.ageMax,S.prix,T.idType,T.denomType,T.descrType,M.idMoni,M.nomMoni,M.prenomMoni,M.adresseMoni,M.sexeMoni,M.naissMoni,dateInscription,datePaiement from "+
"I inscription and P participant and S stage and T Type and M Stage where P.idPart=I.idPart and I.idStage=S.idStage and S.idType=T.idType and S.idMoni=M.idMoni and idPart=? order by 1";


private static final String SQL_SELECT_PAR_STAGE="Select S.idType ,S.dateDeb,S.dateFin,S.ageMin,S.ageMax,S.prix,T.idType,T.denomType,T.descrType,M.idMoni,M.nomMoni,M.prenomMoni,M.adresseMoni,M.sexeMoni,M.naissMoni,dateInscription,,datePaiement from "+
"I inscription and P participant and S stage and T Type and M Stage where P.idPart=I.idPart and I.idStage=S.idStage and S.idType=T.idType and S.idMoni=M.idMoni and idStage=? order by 1";

private static final String SQL_INSERT="INSERT INTO type VALUES (?,?,?)";

private static final String SQL_DELETE="DELETE * from type where idType=?";

private static final String SQL_UPDATE="UPDATE type SET denomType=?,descrType=? WHERE idType= ?";

private  Connection con=null;
private  PreparedStatement prepStat=null;
private  ResultSet resu=null;

    public TypeDaoMysql(DaoFactory daoFactory)
    {
        this.daoFactory = daoFactory;
    }
     public TypeDaoMysql()
    {
        this.daoFactory = daoFactory;
    }
    
    /* renvoie une liste chaînée de toutes les inscriptions existantes */
    
    public ArrayList <Type> selectTypes() throws DaoException
    {
        
        
        ArrayList <Type> myList = new ArrayList();
                     
        try {
            con = daoFactory.getConnection();
            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, (Object[])null);
            resu = prepStat.executeQuery();
            while (resu.next())
            {  
                //creation des objets Type
                myList.add(new Type(resu.getInt(1),resu.getString(2),resu.getString(3)));
            }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
            
        return myList;
    }
  

    @Override
    public ArrayList<Type> selectTypeParPart(Integer partId) throws DaoException {
        ArrayList <Type> myList = new ArrayList();
                     
        try {
            con = daoFactory.getConnection();
            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, partId);
            resu = prepStat.executeQuery();
            while (resu.next())
            {  
                //creation des objets Type
                myList.add(new Type(resu.getInt(1),resu.getString(2),resu.getString(3)));
             }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
            
        return myList; 
    }

    @Override
    public ArrayList<Type> selectTypeParStage(Integer stageId) throws DaoException {
      ArrayList <Type> myList = new ArrayList();
                     
        try {
            con = daoFactory.getConnection();
            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, stageId);
            resu = prepStat.executeQuery();
            while (resu.next())
            {  
                //creation des objets Type
                myList.add(new Type(resu.getInt(1),resu.getString(2),resu.getString(3)));
             }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
            
        return myList;   
    }

    @Override
    public void insertType(Type type) throws DaoException {
        try{
            con=daoFactory.getConnection();
            prepStat=DaoUtil.initialisationRequetePreparee(con, SQL_INSERT, false,
                    type.getIdType(),type.getDenomType(),type.getDescrType());
            resu=prepStat.executeQuery();
        }
        catch(SQLException e){
            throw new DaoException(e);
        }finally{
        DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
    }

    public void deleteType(Integer idType) throws DaoException {
        try {
            /* Récupération d'une connexion depuis la Factory */
            con = daoFactory.getConnection();

            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_DELETE, false, idType);
            prepStat.executeUpdate();
        } 
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
    }

    @Override
    public void updateType(Type type) throws DaoException {
          try {
        /* Récupération d'une connexion depuis la Factory */
        con = daoFactory.getConnection();

            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_UPDATE, false,
                    type.getDenomType(),type.getDescrType(),type.getIdType());
            prepStat.executeUpdate();
        } 
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
    }
    
    
}
