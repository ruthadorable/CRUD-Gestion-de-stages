package src.daoMysql;

import src.beans.*;
import src.dao.*;

import java.util.ArrayList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.DriverManager;

import javax.swing.JOptionPane;


public class ParticipantDaoMysql implements ParticipantDao {
    
    private DaoFactory daoFactory;
    
        
    private static final String SQL_SELECT_TOUS="Select idPart,nomPart,prenomPart,adressePart,sexePart,naissPart from stages.participant order by 1";
   
   
    private static final String SQL_SELECT_PAR_STAGE="Select I.idPart,nomPart,prenomPart,adressePart,sexePart,naissPart ,I.idStage ,dateDeb,dateFin,ageMin,ageMax,prix,idType,denomType,descrType,idMoni,nomMoni,prenomMoni,adresseMoni,sexeMoni,naissMoni,dateInscription,datePaiement from " +
"I inscription and P participant and S stage and T Type and M Moniteur where I.idPart=P.idPart and I.idStage = S.idStage and S.Type =T.Type and S.Moniteur=M.Moniteur where S.idStage=? order by 1";

    private static final String SQL_SELECT_PAR_TYPE="Select I.idPart,nomPart,prenomPart,adressePart,sexePart,naissPart ,I.idStage ,dateDeb,dateFin,ageMin,ageMax,prix,idType,denomType,descrType,idMoni,nomMoni,prenomMoni,adresseMoni,sexeMoni,naissMoni,dateInscription,datePaiement from " +
"I inscription and P participant and S stage and T Type and M Moniteur where I.idPart=P.idPart and I.idStage = S.idStage and S.Type =T.Type and S.Moniteur=M.Moniteur where T.idType=? order by 1";
    
    private static final String SQL_SELECT_PAR_MONITEUR="Select I.idPart,nomPart,prenomPart,adressePart,sexePart,naissPart ,I.idStage ,dateDeb,dateFin,ageMin,ageMax,prix,idType,denomType,descrType,idMoni,nomMoni,prenomMoni,adresseMoni,sexeMoni,naissMoni,dateInscription,datePaiement from " +
"I inscription and P participant and S stage and T Type and M Moniteur where I.idPart=P.idPart and I.idStage = S.idStage and S.Type =T.Type and S.Moniteur=M.Moniteur where M.idMoni=? order by 1";


    private static final String SQL_INSERT="INSERT INTO participant values(?,?,?,?,?,?)";

    private static final String SQL_DELETE="DELETE from participant where idPart=?";

    private static final String SQL_UPDATE="UPDATE participant SET idPart=?, nomPart=?,prenomPart=?, adressePart=? ,sexePart=?,naissPart=? WHERE idPart= ?";

     
    public ParticipantDaoMysql(DaoFactory daoFactory)
    {
        this.daoFactory = daoFactory;
    }

    public ParticipantDaoMysql()
    {
        this.daoFactory = daoFactory;
    }
 
    public ArrayList selectParticipants() throws DaoException {
        ArrayList <Participant> myList = new ArrayList<Participant>();
        Connection con=null;
        PreparedStatement prepStat=null;
        ResultSet resu=null;
                     
        try {
            con = daoFactory.getConnection();
            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, (Object[])null);
            resu = prepStat.executeQuery();
            while (resu.next())
            {  
                //creation de l'objet Participant
                myList.add(new Participant(resu.getInt(1),resu.getString(2),resu.getString(3),resu.getString(4),resu.getString(5),resu.getDate(6)));
             }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
            return myList;
        }
           
    }


    @Override
    public void deleteParticipant(String idPart) throws DaoException {
        Connection con=null;
        PreparedStatement prepStat=null;
        ResultSet resu=null;
    try {
            /* Récupération d'une connexion depuis la Factory */
            con = daoFactory.getConnection();

            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_DELETE, true, idPart);
            prepStat.executeUpdate();
        } 
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
    }

    
    public void updateParticipant(Participant part,int oldId) throws DaoException {
        Connection con=null;
        PreparedStatement prepStat=null;
        ResultSet resu=null;
        Object obj[]={part.getIdPart(),part.getNomPart(),part.getPrenomPart(),part.getAdressePart(),part.getSexePart(),part.getNaissPart(),oldId};
        
       try{
            con=daoFactory.getConnection();
            prepStat=DaoUtil.initialisationRequetePreparee(con, SQL_UPDATE, true,(Object[]) obj);
            prepStat.executeUpdate();
        }
        catch(SQLException e){
            throw new DaoException(e);
        }finally{
        DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
    }
 

    @Override
    public void insertParticipant(Participant part) throws DaoException {
        Connection con=null;
        PreparedStatement prepStat=null;
        ResultSet resu=null;
        
        try{
            con=daoFactory.getConnection();
            prepStat=DaoUtil.initialisationRequetePreparee(con, SQL_INSERT, false,
                    part.getIdPart(),part.getNomPart(),part.getPrenomPart(),part.getAdressePart(),part.getSexePart(),part.getNaissPart());
            prepStat.execute();
        }
        catch(SQLException e){
            throw new DaoException(e);
        }finally{
        DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
    }

    @Override
    public ArrayList selectParticipantParStage(int stageId) throws DaoException {
               ArrayList myList = new ArrayList();
               Connection con=null;
        PreparedStatement prepStat=null;
        ResultSet resu=null;
        
        try {
            con = daoFactory.getConnection();
            if (stageId == -1)
                prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, (Object[])null);
            else
                prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_PAR_STAGE, false, stageId);
            
            resu = prepStat.executeQuery();
            while (resu.next())
            {                
                //création de l'objet Participant
                myList.add(new Participant(resu.getInt(1),resu.getString(2),resu.getString(3),resu.getString(4),resu.getString(5),resu.getDate(6)));
             }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
        
        return myList;
    }

    @Override
    public ArrayList selectParticipantParMoniteur(int moniteurId) throws DaoException {
        ArrayList myList = new ArrayList();
        Connection con=null;
        PreparedStatement prepStat=null;
        ResultSet resu=null;
        
        try {
            con = daoFactory.getConnection();
            if (moniteurId == -1)
                prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, (Object[])null);
            else
                prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_PAR_MONITEUR, false, moniteurId);
            
            resu = prepStat.executeQuery();
            while (resu.next())
            {                
                //création de l'objet Participant
                myList.add(new Participant(resu.getInt(1),resu.getString(2),resu.getString(3),resu.getString(4),resu.getString(5),resu.getDate(6)));
             }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
        
        return myList;
    }


}
