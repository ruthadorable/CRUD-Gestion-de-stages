/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src.daoMysql;

import src.beans.*;
import src.dao.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author RuthA
 */
public class StageDaoMysql implements StageDao {
    private DaoFactory daoFactory;
    
    private static final String SQL_SELECT_TOUS="Select idStage , dateDeb,dateFin,ageMin,ageMax,prix,idType,idMoni from stage";

private static final String SQL_SELECT_PAR_PART="Select S.idStage ,S.dateDeb,S.dateFin,S.ageMin,S.ageMax,S.prix,T.idType,T.denomType,T.descrType,M.idMoni,M.nomMoni,M.prenomMoni,M.adresseMoni,M.sexeMoni,M.naissMoni,dateInscription,datePaiement from "+
"I inscription and P participant and S stage and T Type and M Moniteur where S.idType=T.idType and S.Moniteur=M.Moniteur and S.idStage=I.idStage and I.idPart=P.idPart where I.idPart=? order by 1";


private static final String SQL_SELECT_PAR_MONITEUR="Select S.idStage ,S.dateDeb,S.dateFin,S.ageMin,S.ageMax,S.prix,T.idType,T.denomType,T.descrType,M.idMoni,M.nomMoni,M.prenomMoni,M.adresseMoni,M.sexeMoni,M.naissMoni,dateInscription,,datePaiement from "+
"I inscription and P participant and S stage and T Type and M Moniteur where S.idType=T.idType and S.Moniteur=M.Moniteur and S.idStage=I.idStage and I.idPart=P.idPart where S.idMoni=? order by 1";

private static final String SQL_INSERT="INSERT INTO stage VALUES (?,?,?,?,?,?,?,?)";

private static final String SQL_DELETE="DELETE * from S stage where S.idStage=?";

private static final String SQL_UPDATE="UPDATE stage SET idStage=?, dateDeb=?,dateFin=?,ageMin=?, ageMax=?, prix=? WHERE idStage= ?";

private static final String SQL_UPDATE_PRIX_STAGE="UPDATE stage SET idStage=?, prix= ? WHERE idStage= ?";

private static final String SQL_STAGE_ID="SELECT s.idStage,s.dateDeb,s.dateFin,s.ageMin,s.ageMax,s.prix,s.idType,s.idMoni from stage as s where s.idStage= ?";

private        Connection con=null;
private        PreparedStatement prepStat=null;
private        ResultSet resu=null;
    public StageDaoMysql(DaoFactory daoFactory)
    {
        this.daoFactory = daoFactory;
    }
     public StageDaoMysql()
    {
        this.daoFactory = daoFactory;
    }
    
    /* renvoie une liste chaînée de toutes les inscriptions existantes */
    
    public ArrayList <Stage> selectStages() throws DaoException
    {
        
        
        ArrayList <Stage> myList = new ArrayList<Stage>();
                     
        try {
            con = daoFactory.getConnection();
            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, (Object[])null);
            resu = prepStat.executeQuery();
            while (resu.next())
            {  
                //creation des objets Stage
                Stage s= new Stage();
                s.setIdStage(resu.getInt(1));
                s.setDateDeb(resu.getDate(2));
                s.setDateFin(resu.getDate(3));
                s.setAgeMin(resu.getInt(4));
                s.setAgeMax(resu.getInt(5));
                s.setPrix(resu.getInt(6));
                s.setIdType(resu.getInt(7));
                s.setIdMoni(resu.getInt(8));
                myList.add(s);
                
             }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
            
        return myList;
    }
  

    @Override
    public ArrayList<Stage> selectStageParPart(Integer partId) throws DaoException {
        ArrayList <Stage> myList = new ArrayList();
                     
        try {
            con = daoFactory.getConnection();
            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, partId);
            resu = prepStat.executeQuery();
            while (resu.next())
            {  
                //creation des objets Stage
                myList.add(new Stage(resu.getInt(1),resu.getDate(2),resu.getDate(3),resu.getInt(4),resu.getInt(5),resu.getInt(6),resu.getInt(7),resu.getInt(8)));
             }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
            
        return myList; 
    }

    @Override
    public ArrayList<Stage> selectStageParMoniteur(Integer moniteurId) throws DaoException {
      ArrayList <Stage> myList = new ArrayList();
                     
        try {
            con = daoFactory.getConnection();
            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_SELECT_TOUS, false, moniteurId);
            resu = prepStat.executeQuery();
            while (resu.next())
            {  
                //creation des objets Stage
                myList.add(new Stage(resu.getInt(1),resu.getDate(2),resu.getDate(3),resu.getInt(4),resu.getInt(5),resu.getInt(6),resu.getInt(7),resu.getInt(8)));
             }
        }
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
            
        return myList;   
    }

    @Override
    public void insertStage(Stage stage) throws DaoException {
        try{
            con=daoFactory.getConnection();
            prepStat=DaoUtil.initialisationRequetePreparee(con, SQL_INSERT, false,
                    stage.getIdStage(),stage.getDateDeb(),stage.getDateFin(),stage.getAgeMin(),stage.getAgeMax(),stage.getPrix(),stage.getIdType(),stage.getIdMoni());
            resu=prepStat.executeQuery();
        }
        catch(SQLException e){
            throw new DaoException(e);
        }finally{
        DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
    }

    public void updatePrixStageInInscr(Stage stage, Integer idStage)
    {
    
        try {
        /* Récupération d'une connexion depuis la Factory */
        con = daoFactory.getConnection();

            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_UPDATE_PRIX_STAGE, false,
                    stage.getIdStage(),stage.getPrix(),idStage);
            prepStat.executeUpdate();
        } 
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
    
    }
    public void deleteStage(Integer idStage) throws DaoException {
        try {
            /* Récupération d'une connexion depuis la Factory */
            con = daoFactory.getConnection();

            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_DELETE, false, idStage);
            prepStat.executeUpdate();
        } 
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
    }

    public Stage getStageParId(int id)
    {   Stage s= new Stage();
        try{
            con=daoFactory.getConnection();
            prepStat=DaoUtil.initialisationRequetePreparee(con, SQL_STAGE_ID, false,id);
            resu=prepStat.executeQuery();
            while(resu.next()){
            
            s.setIdStage(resu.getInt(1));
            s.setDateDeb(resu.getDate(2));
            s.setDateFin(resu.getDate(3));
            s.setAgeMin(resu.getInt(4));
            s.setAgeMax(resu.getInt(5));
            s.setPrix(resu.getInt(6));
            s.setIdType(resu.getInt(7));
            s.setIdMoni(resu.getInt(8));
            
            }
        }
        catch(SQLException e){
            throw new DaoException(e);
        }finally{
        DaoUtil.fermeturesSilencieuses(prepStat, con);
        return s;
        }
        
    }
    @Override
    public void updateStage(Stage stage,Integer i) throws DaoException {
          try {
        /* Récupération d'une connexion depuis la Factory */
        con = daoFactory.getConnection();

            prepStat = DaoUtil.initialisationRequetePreparee(con, SQL_UPDATE, false,
                    stage.getDateDeb(), stage.getDateFin(),stage.getAgeMin(),
                    stage.getAgeMax(),stage.getPrix(),stage.getIdStage(),stage.getIdType(),stage.getIdMoni());
            prepStat.executeUpdate();
        } 
        catch (SQLException e) {
            throw new DaoException(e);
        }
        finally {
            DaoUtil.fermeturesSilencieuses(prepStat, con);
        }
    }
    
}
