package src.beans;

import java.time.LocalDate;
import java.util.*;

public class Participant {
    private Integer idPart;
    private  String nomPart;
    private String prenomPart;
    private String adressePart;
    private String sexePart;
    private Date naissPart;
    
    public Participant()
    {
        this.nomPart=null;
        this.prenomPart=null;
        this.adressePart=null;
        this.sexePart=null;
        this.naissPart=null;
    
    }

    public Participant(Integer idPart, String nomPart, String prenomPart, String adressePart,String sexePart, Date naissPart) {
        this.idPart=idPart;
        this.nomPart=nomPart;
        this.prenomPart=prenomPart;
        this.adressePart=adressePart;
        this.sexePart=sexePart;
        this.naissPart=naissPart;
    }

    public void setIdPart(Integer idPart)
    {
        this.idPart=idPart;
    }
    public Integer getIdPart()
    {
    return this.idPart;
    }
    public String getNomPart() {
        return nomPart;
    }

    public void setNomPart(String nomPart) {
        this.nomPart = nomPart;
    }

    public String getPrenomPart() {
        return prenomPart;
    }

    public void setPrenomPart(String prenomPart) {
        this.prenomPart = prenomPart;
    }

    public String getAdressePart() {
        return adressePart;
    }

    public void setAdressePart(String adressePart) {
        this.adressePart = adressePart;
    }

    public String getSexePart() {
        return sexePart;
    }

    public void setSexePart(String sexePart) {
        this.sexePart = sexePart;
    }

    public Date getNaissPart() {
        return naissPart;
    }

    public void setNaissPart(Date naissPart) {
        this.naissPart = naissPart;
    }
 
    
}
