package src.beans;


import java.util.*;
public class Moniteur {
    private Integer idMoni;
    private String nomMoni;
    private String prenomMoni;
    private String adresseMoni;
    private String sexeMoni;
    private String naissMoni;
    private ArrayList <Stage> stages=new ArrayList<>();


    public Moniteur() {
    }

    public Moniteur(Integer idMoni, String nomMoni, String prenomMoni, String adresseMoni, String sexeMoni, String naissMoni) {
        this.idMoni = idMoni;
        this.nomMoni = nomMoni;
        this.prenomMoni = prenomMoni;
        this.adresseMoni = adresseMoni;
        this.sexeMoni = sexeMoni;
        this.naissMoni = naissMoni;
    }

    public Integer getIdMoni() {
        return idMoni;
    }

    public void setIdMoni(Integer idMoni) {
        this.idMoni = idMoni;
    }

    public String getNomMoni() {
        return nomMoni;
    }

    public void setNomMoni(String nomMoni) {
        this.nomMoni = nomMoni;
    }

    public String getPrenomMoni() {
        return prenomMoni;
    }

    public void setPrenomMoni(String prenomMoni) {
        this.prenomMoni = prenomMoni;
    }

    public String getAdresseMoni() {
        return adresseMoni;
    }

    public void setAdresseMoni(String adresseMoni) {
        this.adresseMoni = adresseMoni;
    }

    public String getSexeMoni() {
        return sexeMoni;
    }

    public void setSexeMoni(String sexeMoni) {
        this.sexeMoni = sexeMoni;
    }

    public String getNaissMoni() {
        return naissMoni;
    }

    public void setNaissMoni(String naissMoni) {
        this.naissMoni = naissMoni;
    }


}
