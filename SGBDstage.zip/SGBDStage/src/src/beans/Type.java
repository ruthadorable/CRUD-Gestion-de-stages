package src.beans;


import java.util.*;

public class Type {
    private Integer idType;
    private String denomType;
    private String descrType; 
    private ArrayList <Stage> stages= new ArrayList<>();

    public Type(Integer idType, String denomType, String descrType) {
        this.idType = idType;
        this.denomType = denomType;
        this.descrType = descrType;
    }
    public Type()
    {
        
    }

    public Integer getIdType() {
        return idType;
    }

    public void setIdType(Integer idType) {
        this.idType = idType;
    }

    public String getDenomType() {
        return denomType;
    }

    public void setDenomType(String denomType) {
        this.denomType = denomType;
    }

    public String getDescrType() {
        return descrType;
    }

    public void setDescrType(String descrType) {
        this.descrType = descrType;
    }


}
