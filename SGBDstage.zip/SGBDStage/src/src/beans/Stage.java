package src.beans;



import java.time.*;
import java.util.Date;

public class Stage {
    private Integer idStage;
    private Date dateDeb;
    private Date dateFin;
    private int ageMin;
    private int ageMax;
    private int prix;
    private Type type=new Type();
    private Moniteur mono=new Moniteur();

    public Stage(Integer idStage, Date dateDeb, Date dateFin, int ageMin, int ageMax, int prix, int type,int mono) {
        this.idStage = idStage;
        this.dateDeb = dateDeb;
        this.dateFin = dateFin;
        this.ageMin = ageMin;
        this.ageMax = ageMax;
        this.prix = prix;
        this.type.setIdType(type);
        this.mono.setIdMoni(mono);
    }      
    public Stage() {
    }

    public Integer getIdStage() {
        return idStage;
    }

    public void setIdStage(int idStage) {
        this.idStage = idStage;
    }

    public Date getDateDeb() {
        return dateDeb;
    }

    public void setDateDeb(Date dateDeb) {
        this.dateDeb = dateDeb;
    }

    public Date getDateFin() {
        return dateFin;
    }

    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

    public int getAgeMin() {
        return ageMin;
    }

    public void setAgeMin(int ageMin) {
        this.ageMin = ageMin;
    }

    public int getAgeMax() {
        return ageMax;
    }

    public void setAgeMax(int ageMax) {
        this.ageMax = ageMax;
    }

    public int getPrix() {
        return prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public int getIdType() {
        return this.type.getIdType();
    }

    public void setIdType(int idType) {
        this.type.setIdType(idType);
    }

    public int getIdMoni() {
        return this.mono.getIdMoni();
    }

    public void setIdMoni(int idMoni) {
        this.mono.setIdMoni(idMoni);
    }

    public void getIdStage(Integer valueOf) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   

}
