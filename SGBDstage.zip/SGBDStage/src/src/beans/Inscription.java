package src.beans;


import java.time.*;
import java.util.*;
import src.daoMysql.StageDaoMysql;
public class Inscription {
    private Integer identPart;
    private Integer idInscr;
    private Integer idStage;
    private Date dateInscription;
    private Date datePaiement;
    private Participant participant;
    private Stage stage;
    private static List <Participant> participants = new ArrayList<>(); 
    private static List <Stage> stages=new ArrayList<>();

    public Inscription() {
        identPart=null;
        idInscr=null;
        idStage=null;
        dateInscription=null;
        datePaiement=null;
        participant=null;
        stage=null;
        
    }

    public Inscription(Integer idInscr,Participant part,int idStage, Date dateInscription, Date datePaiement) {
        this.idInscr=idInscr;
        this.participant=part;
        this.stage=new StageDaoMysql().getStageParId(idStage);
        this.idStage=idStage;
        participants.add(part);
        stages.add(stage);
        this.dateInscription = dateInscription;
        this.datePaiement = datePaiement;
    }

    public Integer getIdentPart() {
        return identPart;
    }

    public void setIdentPart(Integer identPart) {
        this.identPart = identPart;
    }

    public Integer getIdStage() {
        return idStage;
    }

    public Integer getIdInscr() {
        return idInscr;
    }

    public void setIdInscr(Integer idInscr) {
        this.idInscr = idInscr;
    }

    public void setIdStage(Integer idStage) {
        this.idStage = idStage;
        this.stage=new Stage();
        this.stage.setIdStage(this.idStage);
    }

    public Date getDateInscription() {
        return dateInscription;
    }

    public void setDateInscription(Date dateInscription) {
        this.dateInscription = dateInscription;
    }

    public Date getDatePaiement() {
        return datePaiement;
    }

    public void setDatePaiement(Date datePaiement) {
        this.datePaiement = datePaiement;
    }

    public List<Participant> getParticipants() {
        return participants;
    }

    public void setParticipants(List<Participant> participants) {
        this.participants = participants;
    }

    public List<Stage> getStages() {
        return stages;
    }

    public void setStages(List<Stage> stages) {
        this.stages = stages;
    }

    public Participant getParticipant() {
        return participant;
    }

    public void setParticipant(Participant participant) {
        this.participant = participant;
    }

    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }
   public Integer getPrixStage()
   {
       return this.stage.getPrix();
   }
   public void setPrixStage(Integer prix)
   {
       this.stage.setPrix(prix);
   }
}
