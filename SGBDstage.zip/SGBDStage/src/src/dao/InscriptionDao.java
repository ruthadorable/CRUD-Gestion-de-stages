/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src.dao;

import java.util.ArrayList;
import src.beans.Inscription;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public interface InscriptionDao {

    public ArrayList <Inscription> selectInscriptions() throws DaoException;

    public void insertInscription (Inscription inscr) ;
    
    public void deleteInscription (Integer idInscription) throws DaoException;
    
    public void updateInscription (Inscription inscr,Integer oldId) throws DaoException;
       

}
