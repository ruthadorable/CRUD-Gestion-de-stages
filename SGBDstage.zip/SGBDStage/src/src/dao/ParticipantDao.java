package src.dao;

import java.util.ArrayList;
import src.beans.Participant;

public interface ParticipantDao {

    

    ArrayList selectParticipants() throws DaoException;
    
    ArrayList selectParticipantParStage(int stageId) throws DaoException;
    
    ArrayList selectParticipantParMoniteur(int moniteurId) throws DaoException;
    

    void insertParticipant(Participant part) throws DaoException;
    
    void deleteParticipant(String ident) throws DaoException;
    
    void updateParticipant(Participant part,int id) throws DaoException;

}
