/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src.dao;

/**
 *
 * @author RuthA
 */
import java.util.ArrayList;
import src.beans.Inscription;
import src.beans.Type;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public interface TypeDao {
    
    ArrayList<Type> selectTypes() throws DaoException;
    
    ArrayList<Type> selectTypeParStage(Integer stageId) throws DaoException;
    
    ArrayList<Type> selectTypeParPart(Integer partId) throws DaoException;
    
    void insertType(Type part) throws DaoException;
    
    void deleteType(Integer ident) throws DaoException;
    
    void updateType(Type part) throws DaoException;

}
