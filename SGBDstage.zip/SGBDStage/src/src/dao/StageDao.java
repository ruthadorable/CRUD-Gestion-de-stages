/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src.dao;

import src.beans.Stage;
import java.util.ArrayList;
import java.util.ArrayList;
import src.beans.Inscription;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author RuthA
 */
public interface StageDao {
    
    ArrayList selectStages() throws DaoException;
    
    ArrayList<Stage> selectStageParPart(Integer partId) throws DaoException;
    
    ArrayList<Stage> selectStageParMoniteur(Integer moniteurId) throws DaoException;
    
    void insertStage(Stage part) throws DaoException;
    
    void deleteStage(Integer idStage) throws DaoException;
    
    void updateStage(Stage part, Integer i) throws DaoException;
    
    

    
}
