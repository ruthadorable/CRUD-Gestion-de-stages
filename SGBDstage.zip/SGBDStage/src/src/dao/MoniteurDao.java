/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src.dao;

import src.beans.Moniteur;
import java.util.ArrayList;

/**
 *
 * @author RuthA
 */
public interface MoniteurDao {
    ArrayList<Moniteur> selectMoniteurs() throws DaoException;
    
    ArrayList<Moniteur> selectMoniteurParStage(Integer stageId) throws DaoException;
    
    ArrayList<Moniteur> selectMoniteurParPart(Integer partId) throws DaoException ;
    
    void insertMoniteur(Moniteur part) throws DaoException;
    
    void deleteMoniteur(Integer idMoni) throws DaoException;
    
    void updateMoniteur(Moniteur part) throws DaoException;

}
