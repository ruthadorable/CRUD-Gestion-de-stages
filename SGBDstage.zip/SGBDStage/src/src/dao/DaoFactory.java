package src.dao;

import src.daoMysql.ParticipantDaoMysql;
import java.io.IOException;
import java.io.InputStream;
import static java.lang.Class.forName;
import java.lang.reflect.Constructor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class DaoFactory {
    private static final String FICHIER_PROPERTIES       = "src/dao/config.properties";
    private static final String PROPERTY_URL             = "url";
    private static final String PROPERTY_DRIVER          = "driver";
    private static final String PROPERTY_NOM_UTILISATEUR = "nomutilisateur";
    private static final String PROPERTY_MOT_DE_PASSE    = "motdepasse";
    private static final String PROPERTY_APP_DAO    = "stagesdao";
    
    private String              url;
    private String              driver;
    private String              username;
    private String              password;
    private String              appDao;

    
    /* Pattern Singleton */
    private static DaoFactory uniqueInstance = new DaoFactory();
    public static DaoFactory getInstance()
    {
        return uniqueInstance;
    }
    
    private DaoFactory() throws DaoConfigurationException
    {
        Properties properties = new Properties();
            
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        InputStream fichierProperties = classLoader.getResourceAsStream( FICHIER_PROPERTIES );

        if (fichierProperties == null) {
            throw new DaoConfigurationException( "Le fichier properties " + FICHIER_PROPERTIES + " est introuvable." );
        }
        
        try {
            properties.load( fichierProperties );
            url = properties.getProperty( PROPERTY_URL );
            driver = properties.getProperty( PROPERTY_DRIVER );
            username = properties.getProperty( PROPERTY_NOM_UTILISATEUR );
            password = properties.getProperty( PROPERTY_MOT_DE_PASSE );
            appDao=properties.getProperty(PROPERTY_APP_DAO);

        } catch (IOException e) {
            throw new DaoConfigurationException( "Impossible de charger le fichier properties " + FICHIER_PROPERTIES, e );
        }

        try {
            Class.forName(driver);
            }
        catch (ClassNotFoundException e)
            {
            throw new DaoConfigurationException("Le driver est introuvable", e);
            }
    }

    public Connection getConnection() throws SQLException
    {
        return DriverManager.getConnection(url, username,password);
    }
    public ParticipantDao getDAOAppareils()
    {
        // new AppareilsDaoMysql();
        try{
        Class appDaoClass = Class.forName(appDao);
        Constructor[] constr=appDaoClass.getConstructors();
        return (ParticipantDao)constr[0].newInstance(this);
        }
        catch(Exception e)
        {
            throw new DaoConfigurationException("Probleme d'injection avec la classe appareils",e);
        }
        finally{
        
        }
    }
    public InscriptionDao getDAOCategories()
    {
        // new AppareilsDaoMysql();
        try{
        Class appDaoClass = Class.forName(appDao);
        Constructor[] constr=appDaoClass.getConstructors();
        return (InscriptionDao)constr[0].newInstance(this);
        }
        catch(Exception e)
        {
            throw new DaoConfigurationException("Probleme d'injection avec la classe appareils",e);
        }
        finally{
        
        }
    }
}
