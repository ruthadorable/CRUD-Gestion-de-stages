package src.presentation;



import src.beans.*;
import src.dao.*;
import src.daoMysql.*;
import java.util.*; // pour ArrayList
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.*;
public class TableModelStages extends AbstractTableModel {
    
    private DefaultTableModel model = new DefaultTableModel();
    private String[] columnNames = {"ID Stage","Date Debut","Date Fin","Age min","Age max","prix","id type","id moniteur"};
    private ArrayList <Stage> myList;
  

    public TableModelStages (ArrayList<Stage> myList)
    {
        this.myList = myList;
        model.setColumnIdentifiers(columnNames);
        Vector <Object> rowData = new Vector();
        StageDaoMysql p=new StageDaoMysql();
        for(int i = 0; i < myList.size(); i++){
            
            
            rowData.add(0,myList.get(i).getIdStage());
            rowData.add(1,myList.get(i).getDateDeb());
            rowData.add(2,myList.get(i).getDateFin());
            rowData.add(3,myList.get(i).getAgeMin());
            rowData.add(4,myList.get(i).getAgeMax());
            rowData.add(5,myList.get(i).getPrix());
            rowData.add(6,myList.get(i).getIdType());
            rowData.add(7,myList.get(i).getIdMoni());
            
            
                System.out.println(rowData);
               model.insertRow(i,rowData);
        };
        
        
    }
    
    public int getColumnCount() {
        return columnNames.length;
    }

    public int getRowCount() {
        return myList.size();
    }

    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }

  

   

    public DefaultTableModel getModel() {
        return model;
    }

    public void setModel(DefaultTableModel model) {
        this.model = model;
    }

    public String[] getColumnNames() {
        return columnNames;
    }

    public void setColumnNames(String[] columnNames) {
        this.columnNames = columnNames;
    }

    public ArrayList<Stage> getMyList() {
        return myList;
    }

    public void setMyList(ArrayList<Stage> myList) {
        this.myList = myList;
    }

    @Override
    public Object getValueAt(int row, int col) {
        Stage myApp = myList.get(row);
        switch (col)
        {
            case 0 :    return myApp.getIdStage();
            case 1 :    return myApp.getDateDeb();
            case 2 :    return myApp.getDateFin();
            case 3 :    return myApp.getAgeMin();
            case 4 :    return myApp.getAgeMax();
            case 5 :    return myApp.getPrix();
            case 6 :    return myApp.getIdType();
            case 7 :    return myApp.getIdMoni();
         

        }
        return null;
    }
    
    
}

