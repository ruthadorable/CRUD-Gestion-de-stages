package src.presentation;



import src.beans.*;
import src.daoMysql.*;
import java.util.*; // pour ArrayList
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.*;

public class TableModelTypes extends AbstractTableModel {
    
    private DefaultTableModel model = new DefaultTableModel();
    private String[] columnNames = {"ID Type","Titre","Description"};
    private ArrayList <Type> myList;
  

    public TableModelTypes (ArrayList<Type> myList)
    {
        this.myList = myList;
        model.setColumnIdentifiers(columnNames);
        Vector <Object> rowData = new Vector();
        ParticipantDaoMysql p=new ParticipantDaoMysql();
        for(int i = 0; i < myList.size(); i++){
            
            
            rowData.add(0,myList.get(i).getIdType());
            rowData.add(1,myList.get(i).getDenomType());
            rowData.add(2,myList.get(i).getDescrType());
               
               model.insertRow(i,rowData);
        };
        
        
    }
    
    public int getColumnCount() {
        return columnNames.length;
    }

    public int getRowCount() {
        return myList.size();
    }

    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }

    @Override
    public Object getValueAt(int row, int col) {
        Type myApp = myList.get(row);
        switch (col)
        {
            case 0 :    return myApp.getIdType();
            case 1 :    return myApp.getDenomType();
            case 2 :    return myApp.getDescrType();
        }
        return null;
    }

    @Override
    public Class getColumnClass(int c) {
        //return getValueAt(0, c).getClass(); ! provoque une erreur quand la table est vide et qu'il y a un sorter !
        switch (c)
        {
            case 0 :    return String.class;
            case 1 :    return String.class;
            case 2 :    return String.class;
            case 3 :    return String.class;
            case 4 :    return String.class;
            case 5 :    return String.class; 
        }
        return null;
    }

    public DefaultTableModel getModel() {
        return model;
    }

    public void setModel(DefaultTableModel model) {
        this.model = model;
    }

    public String[] getColumnNames() {
        return columnNames;
    }

    public void setColumnNames(String[] columnNames) {
        this.columnNames = columnNames;
    }

    public ArrayList<Type> getMyList() {
        return myList;
    }

    public void setMyList(ArrayList<Type> myList) {
        this.myList = myList;
    }
    
    
}

