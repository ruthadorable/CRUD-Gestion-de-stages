package src.presentation;



import src.beans.*;
import src.daoMysql.*;
import java.util.*; // pour ArrayList
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.*;


public class TableModelMoniteurs extends AbstractTableModel {
    
    private DefaultTableModel model = new DefaultTableModel();
    private String[] columnNames = {"idMoni","Nom","Prenom","Adresse","sexe","Date de Naissance"};
    private ArrayList <Moniteur> myList;
  

    public TableModelMoniteurs (ArrayList<Moniteur> myList)
    {
        this.myList = myList;
        model.setColumnIdentifiers(columnNames);
        Vector <Object> rowData = new Vector();
        ParticipantDaoMysql p=new ParticipantDaoMysql();
        for(int i = 0; i < myList.size(); i++){
            
            
            rowData.add(0,myList.get(i).getIdMoni());
            rowData.add(1,myList.get(i).getNomMoni());
            rowData.add(2,myList.get(i).getPrenomMoni());
            rowData.add(3,myList.get(i).getAdresseMoni());
            rowData.add(4,myList.get(i).getSexeMoni());
            rowData.add(5,myList.get(i).getNaissMoni());
                System.out.println(rowData);
               model.insertRow(i,rowData);
        };
        
        
    }
    
    public int getColumnCount() {
        return columnNames.length;
    }

    public int getRowCount() {
        return myList.size();
    }

    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }

    @Override
    public Object getValueAt(int row, int col) {
        Moniteur myApp = myList.get(row);
        switch (col)
        {
            case 0 :    return myApp.getIdMoni();
            case 1 :    return myApp.getNomMoni();
            case 2 :    return myApp.getPrenomMoni();
            case 3 :    return myApp.getAdresseMoni();
            case 4 :    return myApp.getSexeMoni();
            case 5 :    return myApp.getNaissMoni();

        }
        return null;
    }

    @Override
    public Class getColumnClass(int c) {
        //return getValueAt(0, c).getClass(); ! provoque une erreur quand la table est vide et qu'il y a un sorter !
        switch (c)
        {
            case 0 :    return String.class;
            case 1 :    return String.class;
            case 2 :    return String.class;
            case 3 :    return String.class;
            case 4 :    return String.class;
            case 5 :    return String.class; 
        }
        return null;
    }

    public DefaultTableModel getModel() {
        return model;
    }

    public void setModel(DefaultTableModel model) {
        this.model = model;
    }

    public String[] getColumnNames() {
        return columnNames;
    }

    public void setColumnNames(String[] columnNames) {
        this.columnNames = columnNames;
    }

    public ArrayList<Moniteur> getMyList() {
        return myList;
    }

    public void setMyList(ArrayList<Moniteur> myList) {
        this.myList = myList;
    }
    
    
}

