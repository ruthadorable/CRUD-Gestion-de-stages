package src.presentation;



import src.beans.*;
import src.dao.*;
import src.daoMysql.*;
import java.util.*; // pour ArrayList
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.*;

public class TableModelInscriptions extends AbstractTableModel {
    
    private DefaultTableModel model2 = new DefaultTableModel();
    private String[] columnNames = {"ID Inscription","Date Inscription","Date Paiement","ID Part","ID Stage"};
    private ArrayList <Inscription> myList=new <Inscription>ArrayList();
    private Object [] row;

    public TableModelInscriptions (ArrayList<Inscription> myList)
    {
        this.myList = myList;
        model2.setColumnIdentifiers(columnNames);
         row =new Object[11];
        for(int i = 0; i < myList.size(); i++){
            
            
            row[0]=myList.get(i).getIdInscr();
            row[1]=myList.get(i).getDateInscription();
            row[2]=myList.get(i).getDatePaiement();
            row[3]=myList.get(i).getIdentPart();
            row[4]=myList.get(i).getIdStage();
            model2.addRow(row);
            
              
        }
        
        
    }
    
    public int getColumnCount() {
        return columnNames.length;
    }

    public int getRowCount() {
        return myList.size();
    }

    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }

    @Override
    public Object getValueAt(int row, int col) {
        Inscription myApp = myList.get(row);
        switch (col)
        {
            case 0 :    return myApp.getIdInscr();
            case 1 :    return myApp.getDateInscription();
            case 2 :    return myApp.getDatePaiement();
            case 3 :    return myApp.getIdentPart();
            case 4 :    return myApp.getIdStage();
           
        }
        return null;
    }

    @Override
    public Class getColumnClass(int c) {
        //return getValueAt(0, c).getClass(); ! provoque une erreur quand la table est vide et qu'il y a un sorter !
        switch (c)
        {
            case 0 :    return String.class;
            case 1 :    return String.class;
            case 2 :    return String.class;
            case 3 :    return String.class;
            case 4 :    return String.class;
            case 5 :    return String.class; 
        }
        return null;
    }

    public DefaultTableModel getModel() {
        return this.model2;
    }

    public void setModel(DefaultTableModel model) {
        this.model2 = model;
    }

    public String[] getColumnNames() {
        return columnNames;
    }

    public void setColumnNames(String[] columnNames) {
        this.columnNames = columnNames;
    }

    public ArrayList<Inscription> getMyList() {
        return myList;
    }

    public void setMyList(ArrayList<Inscription> myList) {
        this.myList = myList;
    }
    
    
}

