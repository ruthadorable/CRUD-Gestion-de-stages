package src.presentation;



import src.beans.*;
import src.dao.*;
import src.daoMysql.*;
import java.util.*; // pour ArrayList
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.*;

public class TableModelParticipants extends AbstractTableModel {
    
    private DefaultTableModel model = new DefaultTableModel();
    private String[] columnNames = {"Id participant","Nom","Prénom","Adresse","Sexe","Date de naissance"};
    private ArrayList <Participant> myList;
    
  

    public TableModelParticipants (ArrayList<Participant> myList)
    {
        this.myList = myList;
        model.setColumnIdentifiers(columnNames);
        Vector <Object> rowData = new Vector();
        
        for(int i = 0; i < myList.size(); i++){
            
            rowData.add(0,myList.get(i).getIdPart());
             rowData.add(1,myList.get(i).getNomPart());
              rowData.add(2,myList.get(i).getPrenomPart());
               rowData.add(3,myList.get(i).getAdressePart());
               rowData.add(4,myList.get(i).getSexePart());
               rowData.add(5,myList.get(i).getNaissPart());
               model.insertRow(i,rowData);
        }
        
        
    }
    
    public int getColumnCount() {
        return columnNames.length;
    }

    public int getRowCount() {
        return myList.size();
    }

    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }

    @Override
    public Object getValueAt(int row, int col) {
        Participant myApp = myList.get(row);
        switch (col)
        {
            case 0 :    return myApp.getIdPart();
            case 1 :    return myApp.getNomPart();
            case 2 :    return myApp.getPrenomPart();
            case 3 :    return myApp.getAdressePart();
            case 4 :    return myApp.getSexePart();
            case 5 :    return myApp.getNaissPart(); 
        }
        return null;
    }

    @Override
    public Class getColumnClass(int c) {
        //return getValueAt(0, c).getClass(); ! provoque une erreur quand la table est vide et qu'il y a un sorter !
        switch (c)
        {
            case 0 :    return String.class;
            case 1 :    return String.class;
            case 2 :    return String.class;
            case 3 :    return String.class;
            case 4 :    return String.class;
            case 5 :    return String.class; 
        }
        return null;
    }

    public DefaultTableModel getModel() {
        return model;
    }

    public void setModel(DefaultTableModel model) {
        this.model = model;
    }

    public String[] getColumnNames() {
        return columnNames;
    }

    public void setColumnNames(String[] columnNames) {
        this.columnNames = columnNames;
    }

    public ArrayList<Participant> getMyList() {
        return myList;
    }

    public void setMyList(ArrayList<Participant> myList) {
        this.myList = myList;
    }
    
    
}

