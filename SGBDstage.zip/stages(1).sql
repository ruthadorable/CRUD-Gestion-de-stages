-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 28 août 2021 à 17:44
-- Version du serveur :  10.4.13-MariaDB
-- Version de PHP : 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `stages`
--

-- --------------------------------------------------------

--
-- Structure de la table `inscription`
--

CREATE TABLE `inscription` (
  `IdInscr` int(5) NOT NULL,
  `dateInscription` date NOT NULL,
  `datePaiement` date NOT NULL,
  `idPart` int(11) NOT NULL,
  `idStage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `inscription`
--

INSERT INTO `inscription` (`IdInscr`, `dateInscription`, `datePaiement`, `idPart`, `idStage`) VALUES
(1, '2021-07-10', '2021-07-01', 1, 1),
(2, '2021-07-16', '2021-07-17', 2, 2),
(3, '2021-07-10', '2021-07-01', 3, 3),
(4, '2021-08-26', '2021-08-13', 4, 6),
(6, '2021-08-13', '2021-09-14', 36, 4),
(7, '2021-08-31', '2021-08-31', 8, 2),
(8, '2021-08-20', '2021-08-21', 32, 3),
(9, '2021-08-26', '2021-08-13', 22, 5),
(17, '2021-08-20', '2021-08-21', 35, 7),
(25, '2021-08-30', '2021-08-31', 33, 8),
(28, '2021-08-27', '2021-08-31', 47, 6),
(29, '2021-08-30', '2021-08-31', 48, 8),
(30, '2021-08-31', '2021-08-31', 10, 3),
(31, '2021-08-26', '2021-08-31', 16, 1),
(32, '2021-08-31', '2021-09-02', 14, 8),
(33, '2021-08-31', '2021-09-02', 20, 3);

-- --------------------------------------------------------

--
-- Structure de la table `moniteur`
--

CREATE TABLE `moniteur` (
  `idMoni` int(11) NOT NULL,
  `nomMoni` varchar(25) NOT NULL,
  `prenomMoni` varchar(25) NOT NULL,
  `adresseMoni` varchar(25) NOT NULL,
  `sexeMoni` varchar(25) NOT NULL,
  `naissMoni` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `moniteur`
--

INSERT INTO `moniteur` (`idMoni`, `nomMoni`, `prenomMoni`, `adresseMoni`, `sexeMoni`, `naissMoni`) VALUES
(1, 'Danniau', 'Julien', 'Rue de l\'Autonomie 47,106', 'M', '1978-05-04'),
(2, 'Danniau', 'Julien', 'Rue de l\'Autonomie 47,106', 'M', '1978-05-04'),
(3, 'Servais', 'Didier', 'Rue de l\'Astronaute 47,10', 'M', '1975-05-02'),
(4, 'Servais', 'Didier', 'Rue de l\'Astronaute 47,10', 'M', '1975-05-02'),
(5, 'Dupont', 'Caroline', 'Rue de l\'impasse 45 ', 'Femme', '1971-06-07'),
(6, 'Escobar', 'Francis', 'Rue de l\'herbe  98', 'Homme', '1980-06-15'),
(7, 'Lechien', 'Jerome', 'Route de Chatelet 27', 'Homme', '1987-06-16'),
(8, 'Lorentz', 'Pierre-yves', 'Rue de l\'aviation 45', 'Homme', '1981-10-15'),
(9, 'Campos', 'Jeremy', 'Rue pointilleux 44', 'Homme', '1984-06-23');

-- --------------------------------------------------------

--
-- Structure de la table `participant`
--

CREATE TABLE `participant` (
  `idPart` int(11) NOT NULL,
  `nomPart` varchar(25) NOT NULL,
  `prenomPart` varchar(25) NOT NULL,
  `adressePart` varchar(35) NOT NULL,
  `sexePart` varchar(5) NOT NULL,
  `naissPart` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `participant`
--

INSERT INTO `participant` (`idPart`, `nomPart`, `prenomPart`, `adressePart`, `sexePart`, `naissPart`) VALUES
(1, 'Duck', 'Duffy', 'Rue Longchamp 12, Paris', 'Femme', '1995-06-30'),
(2, 'Duck', 'Donald', 'Rue Maréchal 45, Montpell', 'Homme', '1998-04-06'),
(3, 'Rampello', 'Marie', 'Rue des étoiles 46, 1090 Forest', 'Femme', '1994-08-06'),
(4, 'Dupont', 'Matthias', 'Rue du Bonberger 57,1040 Ixelles', 'Homme', '1993-03-04'),
(5, 'Delmotte', 'Gilles', 'Rue des marmottes14 ,6010 Charleroi', 'Femme', '1996-02-02'),
(8, 'Degeyseleer', 'Paulina', 'Giterijstraat 21, 1601 Sint-Pieters', 'Femme', '1996-02-02'),
(9, 'Castaneto', 'Kevin', 'Rue des champs de Mars 48, 42630 Ma', 'Homme', '1998-03-02'),
(10, 'Mendez', 'Isaac', 'Rue de camps romains 14 , Espagne', 'Homme', '1994-06-10'),
(11, 'Guatierri', 'Francesca', '12 Rue feu au bois, 1090 Forest', 'Femme', '1996-05-03'),
(12, 'Guatierri', 'Gianni', 'Rue feu au Bois 48', 'Homme', '1987-06-03'),
(13, 'Dasch', 'Oliver', 'rue de l\' anglophone , Londres', 'Homme', '1987-06-27'),
(14, 'Fracomina', 'Ara', 'Rue de la régence 47,1000 Bruxelles', 'Femme', '1998-06-10'),
(15, 'Lombard', 'Marie', 'rue Lombard 45', 'Femme', '1980-06-14'),
(16, 'Adorable', 'Rose Ann', 'Stationsstraat 21', 'Femme', '1994-07-14'),
(17, 'Haido', 'Miyako', 'Temole Street', 'Femme', '1980-08-19'),
(18, 'Miyazaki', 'Hayao', 'Temple Street', 'Homme', '1987-08-21'),
(19, 'Diaz', 'Cameron', 'Hollywood street 47 ,BeverlyHills', 'Femme', '1978-08-16'),
(20, 'Diaz', 'Hidilyn', 'Manila bay ,Philippines', 'Femme', '1991-11-01'),
(37, 'Barack', 'Obama', 'White House, Washington DC', 'Homme', '1987-08-18'),
(38, 'Dennis', 'Joao', 'Stationsstraat 21, 11235 Antwerpen', 'Homme', '1986-08-04'),
(39, 'Wiart', 'Kevin', 'Stationsstraat 21, Liege', 'Homme', '1988-08-12');

-- --------------------------------------------------------

--
-- Structure de la table `stage`
--

CREATE TABLE `stage` (
  `idStage` int(11) NOT NULL,
  `dateDeb` date NOT NULL,
  `dateFin` date NOT NULL,
  `ageMin` int(11) NOT NULL,
  `ageMax` int(11) NOT NULL,
  `prix` int(11) NOT NULL,
  `idType` int(11) NOT NULL,
  `idMoni` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `stage`
--

INSERT INTO `stage` (`idStage`, `dateDeb`, `dateFin`, `ageMin`, `ageMax`, `prix`, `idType`, `idMoni`) VALUES
(1, '2021-06-30', '2021-09-30', 21, 35, 100, 1, 3),
(2, '2021-02-01', '2021-05-30', 18, 50, 5, 1, 2),
(3, '2022-01-01', '2022-05-25', 18, 50, 12, 2, 3),
(4, '2021-09-01', '2021-11-30', 21, 28, 14, 2, 2),
(6, '2021-06-29', '2021-10-30', 21, 30, 100, 3, 4),
(8, '2022-01-01', '2022-04-30', 21, 35, 0, 4, 2);

-- --------------------------------------------------------

--
-- Structure de la table `type`
--

CREATE TABLE `type` (
  `idType` int(11) NOT NULL,
  `denomType` varchar(25) NOT NULL,
  `descrType` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `type`
--

INSERT INTO `type` (`idType`, `denomType`, `descrType`) VALUES
(1, 'Stage Developpeur Web', 'PROFIL RECHERCHÉ\r\n\r\nCompétences requises : \r\n\r\n- Connaissances dans un framework web\r\n\r\n- Développement front-end (HTML, CSS, Javascript, JQuery) \r\n\r\n- Base de données SQL\r\n\r\nCompétences souhaitées:\r\n\r\n- Connaissance de Ruby et/ou Ruby On Rails\r\n\r\n- Utilisation d’un outil de versioning (Git,..)\r\n\r\n- PostgresSQL\r\n\r\n- Expérience avec Heroku et AWS '),
(2, 'Stage PHP Developpeur Web', 'L\'ENTREPRISE\r\n\r\nBeLead est une agence de développement web basée à Bruxelles, sur l\'avenue de la couronne!\r\n\r\nNous sommes spécialisés dans la création et le développement sur mesure de sites internet et d\'applications mobiles hybrides, ainsi que dans l\'identité visuelle.\r\n\r\nNous proposons des formules «clés en main» offrant ergonomie, simplicité de gestion de l\'ensemble du site internet, et une optimisation pour le référencement.\r\nDESCRIPTION DE LA FONCTION\r\n\r\nEn tant que PHP developer vous prendrez part au développement de sites internet :\r\n\r\n- Vous développerez des nouveaux modules spécifiques et sur mesure pour chaque projets\r\n- Vous serez amené à gérer vos projets de manière autonome mais aussi à travailler en équipe\r\nPROFIL RECHERCHÉ\r\n\r\n- Vous avez de bonnes connaissances de la programmation : PHP, POO & MVC, Javascript, JQuery, HTML5 & CSS\r\n- Vous êtes familier avec les bases de données MySQL\r\n- Vous avez des notions de GIT\r\n- Une bonne connaissance des Framework PHP (Laravel, Symphony, CakePHP,…) est un atout\r\n- Vous avez le sens du travail en équipe, le soucis du détail et l’esprit d’initiative\r\nNOUS OFFRONS\r\n\r\n- Petite entreprise\r\n- Ambiance startup, décontractée\r\n- De nombreux projets amusants\r\n- Kicker le midi pour les amateurs ;-)\r\n'),
(3, 'Designer UX/UI Stage', 'L\'ENTREPRISE\r\n\r\nAlinoa est une agence web et de stratégie digitale.\r\nDESCRIPTION DE LA FONCTION\r\n\r\nTu es un(e) jeune et talentueux(se) Webdesigner(euse) à la recherche d’un stage pour parfaire ta formation et te lancer dans une brillante carrière. Tu recherches un lieu où le partage de connaissances va de paire avec un travail de qualité. Tu as envie de travailler sur des projets variés en contact direct avec les clients de l’agence. Tu seras amené à créer des designs, les présenter et recevoir le(s) feedback(s) du client.\r\nPROFIL RECHERCHÉ\r\n\r\n    Plus qu’une formation, tu as un portfolio garni de projets et tu ne demandes qu’à venir les défendre\r\n    Tu maitrises Photoshop, Sketch ou encore Illustrator\r\n    Tu as un truc qui va nous impressionner… vas-y, montre nous !\r\n    Lieu de travail : Braine-le-Château. C’est donc important que tu puisses te déplacer (défraiement possible).\r\n    Durée du stage : à convenir.\r\n    Période : Place disponible dès maintenant.\r\n\r\nNOUS OFFRONS\r\n\r\n    Une ambiance de travail sans prise de tête,\r\n    Un stage doit te permettre de parachever ta formation, pas de servir le café,.. ;-)\r\n\r\n'),
(4, 'Stage developpeur d\'appli', 'FUNCTION DESCRIPTION\r\n\r\n    développement du Back-end et du CMS( content management system)\r\n    développment du Front-end \r\n\r\nREQUIRED PROFILE\r\n\r\n    Une personne qui aime être challenger et qui est auto-dictate \r\n    Motivé de développer en parti une application mobile dans le domaine du sports et losirs qui sera lancé dans la plupart des universités francophones et flamandes en Belgique\r\n    developpeur en IOS/Android\r\n    ou developpeur en React Native\r\n\r\nWE OFFER\r\n\r\nUne expérience pas comme les autres, où  vous serez entourés toute la journée par des entrepreneurs qui travaille sur différents projets (dans un incubateur de startup), vous aurez des responsabilités et l\'occasion d\'apprendre et de travailler en équipe.\r\n\r\nLa chance de voir comment une start-up fonctionne et s\'aggrandit. \r\n\r\nAvoir une contribution dans le développement de l\'application qui serait lancé au niveau nationale'),
(5, 'Designer UX/UI Stage', 'L\'ENTREPRISE\r\n\r\nAlinoa est une agence web et de stratégie digitale.\r\nDESCRIPTION DE LA FONCTION\r\n\r\nTu es un(e) jeune et talentueux(se) Webdesigner(euse) à la recherche d’un stage pour parfaire ta formation et te lancer dans une brillante carrière. Tu recherches un lieu où le partage de connaissances va de paire avec un travail de qualité. Tu as envie de travailler sur des projets variés en contact direct avec les clients de l’agence. Tu seras amené à créer des designs, les présenter et recevoir le(s) feedback(s) du client.\r\nPROFIL RECHERCHÉ\r\n\r\n    Plus qu’une formation, tu as un portfolio garni de projets et tu ne demandes qu’à venir les défendre\r\n    Tu maitrises Photoshop, Sketch ou encore Illustrator\r\n    Tu as un truc qui va nous impressionner… vas-y, montre nous !\r\n    Lieu de travail : Braine-le-Château. C’est donc important que tu puisses te déplacer (défraiement possible).\r\n    Durée du stage : à convenir.\r\n    Période : Place disponible dès maintenant.\r\n\r\nNOUS OFFRONS\r\n\r\n    Une ambiance de travail sans prise de tête,\r\n    Un stage doit te permettre de parachever ta formation, pas de servir le café,.. ;-)\r\n\r\n'),
(6, 'Stage developpeur d\'appli', 'FUNCTION DESCRIPTION\r\n\r\n    développement du Back-end et du CMS( content management system)\r\n    développment du Front-end \r\n\r\nREQUIRED PROFILE\r\n\r\n    Une personne qui aime être challenger et qui est auto-dictate \r\n    Motivé de développer en parti une application mobile dans le domaine du sports et losirs qui sera lancé dans la plupart des universités francophones et flamandes en Belgique\r\n    developpeur en IOS/Android\r\n    ou developpeur en React Native\r\n\r\nWE OFFER\r\n\r\nUne expérience pas comme les autres, où  vous serez entourés toute la journée par des entrepreneurs qui travaille sur différents projets (dans un incubateur de startup), vous aurez des responsabilités et l\'occasion d\'apprendre et de travailler en équipe.\r\n\r\nLa chance de voir comment une start-up fonctionne et s\'aggrandit. \r\n\r\nAvoir une contribution dans le développement de l\'application qui serait lancé au niveau nationale'),
(7, 'null logo Développeur mob', 'L\'ENTREPRISE\r\n\r\nGarer son véhicule dans les grandes villes européennes est devenu un véritable casse tête pour les conducteurs de voiture dans les grandes villes. Beego vous permet de trouver facilement un parking à court terme partout en voirie.\r\nDESCRIPTION DE LA FONCTION\r\n\r\nTu souhaites effectuer un stage dans une start-up en plein lancement et certainement avoir uneopportunité de travail qui pourrait en découler par la suite ? Si tu aimes le développement et les applications mobiles, cette offre de stage est faite pour toi ! Nous recherchons un développeur qui deviendra responsable de l\'application. En plus de se former sur le t\'as, le stagiaire aura la responsabilité, avec son manager, de développer l\'application.\r\nPROFIL RECHERCHÉ\r\n\r\n•Vous êtes disponible pour 2 mois ou plus •Vous êtes autonome •Des connaissances iOS et/ou Android sont un vrai atout. •Vous êtes prêt à apprendre une nouvelle technologie/language et rapidement l’expérimenter en produisant un prototype. •Vous avez de bonnes compétences relationnelles et comprenez le besoin client •Vous êtes capable d’apprendre rapidement et de prendre des initiatives •Vous êtes motivé et voulez apprendre et évoluer dans un environnement dynamique et agréable.\r\nNOUS OFFRONS\r\n\r\nNous vous offrons une opportunité de travail une fois votre stage fini, dans le cas où votre ambition serait à la hauteur de nos espérances.\r\n'),
(8, 'null logo Développeur mob', 'L\'ENTREPRISE\r\n\r\nGarer son véhicule dans les grandes villes européennes est devenu un véritable casse tête pour les conducteurs de voiture dans les grandes villes. Beego vous permet de trouver facilement un parking à court terme partout en voirie.\r\nDESCRIPTION DE LA FONCTION\r\n\r\nTu souhaites effectuer un stage dans une start-up en plein lancement et certainement avoir uneopportunité de travail qui pourrait en découler par la suite ? Si tu aimes le développement et les applications mobiles, cette offre de stage est faite pour toi ! Nous recherchons un développeur qui deviendra responsable de l\'application. En plus de se former sur le t\'as, le stagiaire aura la responsabilité, avec son manager, de développer l\'application.\r\nPROFIL RECHERCHÉ\r\n\r\n•Vous êtes disponible pour 2 mois ou plus •Vous êtes autonome •Des connaissances iOS et/ou Android sont un vrai atout. •Vous êtes prêt à apprendre une nouvelle technologie/language et rapidement l’expérimenter en produisant un prototype. •Vous avez de bonnes compétences relationnelles et comprenez le besoin client •Vous êtes capable d’apprendre rapidement et de prendre des initiatives •Vous êtes motivé et voulez apprendre et évoluer dans un environnement dynamique et agréable.\r\nNOUS OFFRONS\r\n\r\nNous vous offrons une opportunité de travail une fois votre stage fini, dans le cas où votre ambition serait à la hauteur de nos espérances.\r\n'),
(9, 'company_logos_128011_1483', 'L\'ENTREPRISE\r\n\r\nKERN IT est une société basée sur Bruxelles. \r\n\r\nNous développons des applications web/mobile sur-mesure ainsi que des sites web.\r\n\r\nNos spécialités sont le prototypage et les études de faisabiilté.\r\n\r\nNous fournissons également du conseil.\r\nDESCRIPTION DE LA FONCTION\r\n\r\nNous avons plusieurs projets possibles\r\n\r\n    Continuer le développement d\'une de nos applications web\r\n    Continuer le développement d\'une application mobile android\r\n    R&D en solution de backups\r\n    Mise en place d\'infrastructure\r\n    Développement de sites webs de type vitrine\r\n\r\nPROFIL RECHERCHÉ\r\n\r\nNous recherchons un étudiant ayant déjà des connaissances de base et un interêt pour un ou des domaines suivants :\r\n\r\n    Web ou mobile developpement\r\n    Infrastructure et virtualisation\r\n\r\nLes requis pour les developpeurs (selon le projet):\r\n\r\n    Python\r\n    Twitter Bootstrap\r\n    HTML/CSS/JS ( jquery minimum )\r\n    Avoir déjà développé un siteweb ou une application et de préférence à l\'aide d\'un framework\r\n    Mysql ou postgresql\r\n    Analyse\r\n    Rédaction de rapport et de documentation\r\n    Administration linux\r\n\r\nLes plus:\r\n\r\n    GIT\r\n    Android\r\n    React JS\r\n    Recat Native\r\n\r\nAvoir un interêt pour le monde de l\'entrepreunariat et des startups\r\nAutonomie et créativitié dans le travail\r\n\r\nLa durée du stage doit être d\'au moins 3 mois.\r\n\r\nL\'étudiant doit être en bachelier ou master dans un établissement basé en Belgique.\r\nNOUS OFFRONS\r\n\r\nEtant donnée la taille de l\'équipe, nous offrons une expérience complète au sein d\'une petite entreprise.\r\n\r\nLe stagiaire sera encadré par plusieurs personnes selon le projet choisi. Néanmoins, il devra faire preuve d\'une grande autonomie.\r\n\r\nCertains projets nécessiteront une implication à tous les niveaux, de la définition du projet au suivi.\r\n\r\nUne assurance de l\'établissement est obligatoire.\r\n\r\nLe stage est non rémunéré.\r\n'),
(10, 'company_logos_128011_1483', 'L\'ENTREPRISE\r\n\r\nKERN IT est une société basée sur Bruxelles. \r\n\r\nNous développons des applications web/mobile sur-mesure ainsi que des sites web.\r\n\r\nNos spécialités sont le prototypage et les études de faisabiilté.\r\n\r\nNous fournissons également du conseil.\r\nDESCRIPTION DE LA FONCTION\r\n\r\nNous avons plusieurs projets possibles\r\n\r\n    Continuer le développement d\'une de nos applications web\r\n    Continuer le développement d\'une application mobile android\r\n    R&D en solution de backups\r\n    Mise en place d\'infrastructure\r\n    Développement de sites webs de type vitrine\r\n\r\nPROFIL RECHERCHÉ\r\n\r\nNous recherchons un étudiant ayant déjà des connaissances de base et un interêt pour un ou des domaines suivants :\r\n\r\n    Web ou mobile developpement\r\n    Infrastructure et virtualisation\r\n\r\nLes requis pour les developpeurs (selon le projet):\r\n\r\n    Python\r\n    Twitter Bootstrap\r\n    HTML/CSS/JS ( jquery minimum )\r\n    Avoir déjà développé un siteweb ou une application et de préférence à l\'aide d\'un framework\r\n    Mysql ou postgresql\r\n    Analyse\r\n    Rédaction de rapport et de documentation\r\n    Administration linux\r\n\r\nLes plus:\r\n\r\n    GIT\r\n    Android\r\n    React JS\r\n    Recat Native\r\n\r\nAvoir un interêt pour le monde de l\'entrepreunariat et des startups\r\nAutonomie et créativitié dans le travail\r\n\r\nLa durée du stage doit être d\'au moins 3 mois.\r\n\r\nL\'étudiant doit être en bachelier ou master dans un établissement basé en Belgique.\r\nNOUS OFFRONS\r\n\r\nEtant donnée la taille de l\'équipe, nous offrons une expérience complète au sein d\'une petite entreprise.\r\n\r\nLe stagiaire sera encadré par plusieurs personnes selon le projet choisi. Néanmoins, il devra faire preuve d\'une grande autonomie.\r\n\r\nCertains projets nécessiteront une implication à tous les niveaux, de la définition du projet au suivi.\r\n\r\nUne assurance de l\'établissement est obligatoire.\r\n\r\nLe stage est non rémunéré.\r\n'),
(11, 'Stage en programmation we', 'Vous rejoindrez un projet de développement d’un ERP Saas de gestion de cours particuliers à domicile. Utilisé depuis 2006, cet outil permet la gestion de milliers de prestataires et de milliers d’élèves: inscription, gestion des cours, suivi des prestations, gestions des enquêtes d’évaluation, gestion des paiements,… De nouvelles fonctionnalités sont développées chaque année et vous pourrez prendre en charge le développement complet d’un de ces projets de A à Z : analyse fonctionnelle, développement, implémentation, tests,… Le système dispose d’une API permettant de séparer les projets back-end et front-end.'),
(12, 'Stage en programmation we', 'Vous rejoindrez un projet de développement d’un ERP Saas de gestion de cours particuliers à domicile. Utilisé depuis 2006, cet outil permet la gestion de milliers de prestataires et de milliers d’élèves: inscription, gestion des cours, suivi des prestations, gestions des enquêtes d’évaluation, gestion des paiements,… De nouvelles fonctionnalités sont développées chaque année et vous pourrez prendre en charge le développement complet d’un de ces projets de A à Z : analyse fonctionnelle, développement, implémentation, tests,… Le système dispose d’une API permettant de séparer les projets back-end et front-end.');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `inscription`
--
ALTER TABLE `inscription`
  ADD PRIMARY KEY (`IdInscr`),
  ADD KEY `FK_stageinscr` (`idStage`),
  ADD KEY `FK_partinscr` (`idPart`);

--
-- Index pour la table `moniteur`
--
ALTER TABLE `moniteur`
  ADD PRIMARY KEY (`idMoni`);

--
-- Index pour la table `participant`
--
ALTER TABLE `participant`
  ADD PRIMARY KEY (`idPart`);

--
-- Index pour la table `stage`
--
ALTER TABLE `stage`
  ADD PRIMARY KEY (`idStage`),
  ADD KEY `FK_stagemoni` (`idMoni`),
  ADD KEY `FK_stagetype` (`idType`);

--
-- Index pour la table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`idType`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `inscription`
--
ALTER TABLE `inscription`
  MODIFY `IdInscr` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT pour la table `moniteur`
--
ALTER TABLE `moniteur`
  MODIFY `idMoni` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `participant`
--
ALTER TABLE `participant`
  MODIFY `idPart` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT pour la table `stage`
--
ALTER TABLE `stage`
  MODIFY `idStage` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `type`
--
ALTER TABLE `type`
  MODIFY `idType` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `stage`
--
ALTER TABLE `stage`
  ADD CONSTRAINT `FK_stagemoni` FOREIGN KEY (`idMoni`) REFERENCES `moniteur` (`idMoni`),
  ADD CONSTRAINT `FK_stagetype` FOREIGN KEY (`idType`) REFERENCES `type` (`idType`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
